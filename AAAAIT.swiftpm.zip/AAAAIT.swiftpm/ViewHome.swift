import SwiftUI

struct ViewHome: View {
    @State private var showPopup: Bool = false
    @State private var fullscreenImageIndex: Int? = nil
    
    let images = [
        "app1", "app2", "app3", "app4", "app5", "app6"
    ]
    
    let imageTexts = [
        "1. Un'App sulle App\nQuesto è un processo di progettazione che ti porta dall'ideazione alla creazione di prototipi di app e infine a un'app finita. Questo pulsante di informazioni ti dà una panoramica del contenuto dell'app.",
        "2. Disegnare\nNella scheda Disegnare, puoi fare schizzi con gli strumenti integrati e spiegare le tue idee, oltre a sviluppare i design. Fai clic su 'Generazione di idee' per disegnare 8 idee di app, da cui potrai successivamente scegliere la migliore. In 'Vuoto', 'iPhone' e 'iPad' puoi progettare i layout della tua app in diversi formati.",
        "3. Libero\nQuando fai clic su Libero, puoi scaricare una mappa mentale in Freeform per collegare tutte le tue idee. Nella mappa mentale, puoi trascinare diversi tipi di pulsanti, cornici di iPhone e note nella tua area di lavoro. Se preferisci, puoi anche fare una mappa mentale tradizionale su carta.",
        "4. Materiali\nIn Materiali, puoi scaricare modelli Keynote per creare prototipi della tua app, che si tratti di Apple Watch, iPhone, iPad o MacBook. Ogni modello di Keynote è unico e offre diverse impostazioni per i tuoi layout. Puoi anche scaricare materiali didattici per il progetto e attività per studenti. Se vuoi, puoi anche scaricare materiali specifici per insegnare la programmazione in Swift.",
        "5. App\nNella scheda App, puoi imparare come iniziare a programmare in Swift. Qui puoi esplorare i materiali di Apple 'Get Started with Code' e 'About Me'. In particolare per 'Un'App sulle App', puoi scaricare 4 app che ti insegnano come creare barre di navigazione (menu), Stack Views (organizzazione degli oggetti), inserire contenuti (aggiungere testi, immagini, video e link) e varie funzioni utili.",
        "6. Portfolio\nNella sezione Portfolio, puoi aggiornare e documentare il tuo percorso dall'idea, al design, ai feedback e ai prototipi fino all'app finale. Nel portfolio, puoi caricare foto dalla tua galleria e descrivere la tua esperienza con testi. Alla fine del portfolio, puoi aggiungere altri campi di immagine e testo."
    ]
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            GeometryReader { geometry in
                
                let imageSize = geometry.size.width / 10.65
                
                VStack(alignment: .center, spacing: 30) {
                    Text("Un'App sulle App")
                        .font(.system(size: 50, weight: .bold))
                        .foregroundColor(Color(red: 255 / 255, green: 150 / 255, blue: 141 / 255))
                        .padding(.top, 60)
                        .frame(maxWidth: 600)
                    
                    Image("LOGO")
                        .resizable()
                        .aspectRatio(2.4/1, contentMode: .fit)
                        .padding(.horizontal, imageSize)
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0))
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                        .padding(-30)
                    
                    Text("Un'App sulle App ti aiuta a passare dallo sviluppo delle idee, a disegnare e descrivere quelle idee, fino a creare prototipi di app. Se vuoi, puoi anche imparare a programmare in Swift, così un giorno potrai pubblicare una vera app su App Store. Dai vita alle tue visioni e idee! Clicca sul pulsante delle informazioni per ottenere una panoramica delle diverse sezioni dell'app.")
                        .font(.system(size: 20, weight: .regular))
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0))
                        .frame(maxWidth: 800)
                        .multilineTextAlignment(.center)
                    
                    Text("Clicca sul pulsante delle informazioni per ottenere una panoramica delle diverse sezioni dell'app.")
                        .font(.system(size: 20, weight: .regular))
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0))
                        .frame(maxWidth: 800)
                        .multilineTextAlignment(.center)
                    
                }
     
                .padding(.bottom, 100)
                
                Spacer()
                
                    .padding()
                
                VStack {
                    Spacer()
                    
                    HStack {
                        Spacer()
                        
                        Button(action: {
                            showPopup.toggle()
                        }) {
                            Image(systemName: "info.circle")
                                .font(.largeTitle)
                                .padding()
                                .foregroundColor(.black)
                                .clipShape(Circle())
                        }
                        .padding(.trailing, 20)
                        .padding(.bottom, 20)
                    }
                }
                
                if showPopup {
                    PopupView2(showPopup: $showPopup, images: images, imageTexts: imageTexts, fullscreenImageIndex: $fullscreenImageIndex)
                        .transition(.scale)
                        .zIndex(1)
                }
                
                if let index = fullscreenImageIndex {
                    FullScreenImageView(images: images, imageTexts: imageTexts, currentIndex: index, fullscreenImageIndex: $fullscreenImageIndex)
                        .zIndex(2)
                }
            }
        }
    }
}
struct PopupView2: View {
    @Binding var showPopup: Bool
    let images: [String]
    let imageTexts: [String]
    @State private var currentPage: Int = 0
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        VStack(spacing: 20) {
          Text("Che cos'è un'App sulle App?")
                .font(.headline)
                .padding()
            
            TabView(selection: $currentPage) {
                ForEach(0..<images.count, id: \.self) { index in
                    VStack {
                        Image(images[index])
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 400, height: 300)
                            .onTapGesture {
                                fullscreenImageIndex = index
                            }
                        
                        Text(imageTexts[index])
                            .font(.body)
                            .multilineTextAlignment(.center)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, maxHeight: 200)  
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .tag(index)
                }
            }
            .tabViewStyle(PageTabViewStyle())
            .frame(width: 600, height: 400)
            
            Text("\(currentPage + 1) of \(images.count)")
                .font(.footnote)
                .padding(-10)
            
            Button(action: {
                showPopup = false
            }) {
                Image(systemName: "xmark.circle")
                    .font(.title2)
                    .padding()
                    .foregroundColor(.black)
                    .cornerRadius(10)
            }
        }
        .frame(width: 600, height: 600)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(radius: 20)
        .padding()
    }
}
struct FullScreenImageView: View {
    let images: [String]
    let imageTexts: [String]
    @State var currentIndex: Int
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack {
                Spacer()
                
                TabView(selection: $currentIndex) {
                    ForEach(0..<images.count, id: \.self) { index in
                        Image(images[index])
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .onTapGesture {
                                fullscreenImageIndex = nil
                            }
                            .padding()
                            .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle())
                .indexViewStyle(PageIndexViewStyle())
                
                Text(imageTexts[currentIndex])
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color.white)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                    )
                    .padding()
                    .foregroundColor(.black)
                    .multilineTextAlignment(.center)
                
                Text("\(currentIndex + 1) of \(images.count)")
                    .font(.footnote)
                    .padding(.bottom, 10)
                
                Spacer()
            }
        }
    }
}

struct ViewHome_Previews: PreviewProvider {
    static var previews: some View {
        ViewHome()
    }
}

