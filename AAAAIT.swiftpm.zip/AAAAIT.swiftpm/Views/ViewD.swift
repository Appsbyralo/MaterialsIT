import SwiftUI

struct ViewD: View {
    
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            VStack {
               
                VStack {
                    Text("App che puoi usare come blocchi e fonti di ispirazione")
                        .font(.title)
                        .foregroundColor(.black)
                        .fontWeight(.bold)
                        .padding(.bottom, 5)
                    
                    Text("In questa pagina, devi descrivere cosa dovrebbe includere la tua app, come dovrebbe apparire e perché. Questo lavoro deve essere riassunto in un documento su lavagna in Freeform. Abbiamo creato un modello per te. Puoi scaricarlo facendo clic sull'icona dell'app Freeform qui sotto. Una volta scaricato il documento, dovrai duplicarlo. Ottieni maggiori informazioni nel pulsante di informazioni su questa pagina.")
                        .font(.subheadline)
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .lineLimit(10)
                        .minimumScaleFactor(0.5)
                        .padding(.bottom, 20)
                    
                    ScrollView {
                        LazyVGrid(columns: columns, spacing: 20) {
                            contentBox(title: "Inizia con il codice", description: "Un ottimo punto di partenza per il tuo viaggio nella programmazione.", linkURL: "")
                            
                            contentBox(title: "Su di me", description: "Crea un progetto su te stesso e impara a programmare mentre costruisci la tua prima app.", linkURL: "")
                            
                            contentBox(title: "Crea una barra di navigazione", description: "Impara a creare un menu con tre o più pulsanti. Questa app è inclusa nel tuo abbonamento a 'Un'App sulle App' nella pagina principale di Swift. Scorri verso il basso e trova l'app della barra di navigazione.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                            
                            contentBox(title: "Stack Views", description: "Impara a posizionare oggetti orizzontalmente, verticalmente e lungo l'asse Z o combinare le diverse opzioni. Questa app è inclusa nel tuo abbonamento a 'Un'App sulle App' nella pagina principale di Swift. Scorri verso il basso e trova l'app Stack Views.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                            
                            contentBox(title: "Inserisci contenuti", description: "Impara a inserire foto, video e link nella tua app. Questa app è inclusa nel tuo abbonamento a 'Un'App sulle App' nella pagina principale di Swift. Scorri verso il basso e trova l'app per inserire contenuti.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                            
                            contentBox(title: "Elementi per iniziare", description: "Questa è un'app con diverse idee, come mappe GPS di Apple Maps e vari tipi di pulsanti che possono rendere la tua app unica. Questa app è inclusa nel tuo abbonamento a 'Un'App sulle App' nella pagina principale di Swift. Scorri verso il basso e trova l'app degli elementi per iniziare.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                        
                        }
                    }
                    }
                    .padding()
                }
            }
        }
    }
    
    @ViewBuilder
    private func contentBox(title: String, description: String, linkURL: String, actionURL: String? = nil) -> some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
                .lineLimit(2)
                .minimumScaleFactor(0.5)
                .foregroundColor(.black) 
            
            Divider()  
            
            Text(description)
                .font(.subheadline)
                .foregroundColor(.black) 
            
            Text("Enlace")
                .font(.subheadline)
                .foregroundColor(.blue)
                .underline()
                .onTapGesture {
                    if let url = URL(string: linkURL) {
                        UIApplication.shared.open(url)
                    }
                }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(radius: 5)
        .frame(height: 200)  
        .padding(.horizontal)
        .onTapGesture {
            if let urlString = actionURL, let url = URL(string: urlString) {
                UIApplication.shared.open(url)
            }
        }
    }


struct ViewD_Previews: PreviewProvider {
    static var previews: some View {
        ViewD()
    }
}

