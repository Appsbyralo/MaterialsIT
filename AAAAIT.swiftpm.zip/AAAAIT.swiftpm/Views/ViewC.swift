import SwiftUI

struct ViewC: View {
    @State private var showPopup: Bool = false
    @State private var fullscreenImageIndex: Int? = nil
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    let images = [
        "keynote1", "keynote2", "keynote3", "keynote4", "keynote5", "keynote6", "keynote7"
    ] + [
        "shortcuts", "shortcut1", "shortcut2", "shortcut3", "shortcut4", "shortcut5", "shortcut6", "shortcut7"
    ]
    
    @State private var imageTexts = [
        "1. Qui puoi scaricare la bussola delle idee per scegliere la tua migliore idea. Puoi anche scaricare AppGPT, un chatbot che ti aiuta a sviluppare la tua idea di app, una presentazione One Pager per presentare la tua idea di app e un'analisi della tua app preferita.",
        "2. App prototipo per iPad in Keynote\nIn questo file Keynote riceverai un tema personalizzato per sviluppare il prototipo della tua app per iPad. Facendo clic su + per aggiungere una nuova diapositiva, puoi scegliere tra una varietà di layout per mostrare al meglio le tue idee.",
        "3. App prototipo per iPhone in Keynote\nIn questo file Keynote riceverai un tema personalizzato per sviluppare il prototipo della tua app per iPhone. Facendo clic su + per aggiungere una nuova diapositiva, puoi scegliere tra diversi layout per comunicare efficacemente le tue idee.",
        "4. App prototipo per MacBook in Keynote\nIn questo file Keynote riceverai un tema speciale per creare il prototipo della tua app per MacBook. Premendo + per aggiungere una nuova diapositiva, puoi scegliere tra diversi layout per presentare chiaramente le tue idee.",
        "5. App prototipo per Apple Watch in Keynote\nIn questo file Keynote riceverai un tema unico per progettare il prototipo della tua app per Apple Watch. Premendo + per aggiungere una nuova diapositiva, puoi scegliere tra diversi layout per comunicare efficacemente le tue idee.",
        "6. Materiali educativi\nNei materiali educativi riceverai risorse che ti aiuteranno, come insegnante, a iniziare il progetto 'Un'App sulle App' con sicurezza. Puoi scaricare un libro Keynote che ti guiderà attraverso tutti i passaggi dall'idea all'app prototipo.",
        "7. Materiali educativi in Swift\nInoltre, puoi scaricare un libro Keynote che si concentra su come iniziare a programmare in Swift e supportare le app nella scheda 'App' durante le tue lezioni.",
        "Crea un collegamento per la tua app",
        "1. Apri l'app Comandi Rapidi sul tuo iPad.",
        "2. Premi il \"+\" per creare un nuovo collegamento alla tua schermata home.",
        "3. Cerca Keynote nel campo di ricerca. Ora seleziona il comando rapido 'Riproduci presentazione in modalità spettatore'.",
        "4. Premi sulla presentazione Keynote per selezionare il file che si aprirà quando verrà premuto il collegamento.",
        "5. Ora premi sulla freccia e cambia il nome del collegamento premendo 'Rinomina'. Scegli un'icona per il collegamento e infine premi 'Aggiungi alla schermata home'.",
        "6. Premi su 'Aggiungi' per aggiungere il collegamento alla schermata home.",
        "7. Ora hai creato un collegamento nella tua schermata home."
    ]
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            VStack {
                VStack {
                    Text("Crea un prototipo con botones de cambio de página")
                        .font(.title)
                        .foregroundColor(.black)
                        .fontWeight(.bold)
                        .padding(.bottom, 5)
                    
                    Text("In questa pagina puoi scaricare materiali per studenti, analizzare le tue idee di app e scegliere la migliore. Puoi anche scaricare materiali per lavorare con la tua app preferita, creare una presentazione One Pager e scaricare AppGPT, un chatbot che ti aiuta a riflettere sulla tua idea di app. Inoltre, puoi scaricare file di prototipi di app in Keynote, progettati per iPad, iPhone, MacBook e Apple Watch. Come insegnante, puoi anche scaricare materiali educativi, inclusi risorse per facilitare il progetto didattico e materiali incentrati sulla programmazione in Swift.")
                        .font(.subheadline)
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .lineLimit(10)
                        .minimumScaleFactor(0.5)
                        .padding(.bottom, 20)
                }
                
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 20) {
                        contentBox(title: "Materiali per studenti", description: "Clicca qui per scaricare la bussola delle idee, AppGPT, La mia app preferita e la presentazione One Pager.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                        
                        contentBox(title: "Prototipo di app per iPad", description: "Clicca qui per scaricare il file Keynote del prototipo per iPad. Sviluppa le tue idee senza problemi.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20app%20iPad.key")
                        
                        contentBox(title: "Prototipo di app per iPhone", description: "Clicca qui per scaricare il file Keynote del prototipo per iPhone. Dai vita alle tue idee di app.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20iPhone.key.zip")
                        
                        contentBox(title: "Prototipo di app per Mac", description: "Clicca qui per scaricare il file Keynote del prototipo per Mac. Progetta e perfeziona i tuoi concetti.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20app%20MacBook.key.zip")
                        
                        contentBox(title: "Prototipo di app per Apple Watch", description: "Clicca qui per scaricare il file Keynote del prototipo per Apple Watch. Innova e visualizza la tua app.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20Apple%20Watch.key")
                        
                        contentBox(title: "Materiale educativo", description: "Una guida completa per 'Un'App sulle App'. Scarica libri Keynote per aiutarti a iniziare e insegnare la programmazione in Swift.", linkURL: "https://app.box.com/s/b6a1m1jguxyx5fp6a476tbo0tfcn6gjf")
                        
                        contentBox(title: "Materiali educativi in Swift", description: "Puoi anche scaricare un libro Keynote che si concentra su come iniziare a programmare in Swift e supportare le app nella scheda 'App' durante l'insegnamento.", linkURL: "https://app.box.com/s/76jghz4hifyu5e4uh8egap5jk21ocwj5")
                    }
                
                    .padding()
                }
            }
                
                Spacer()
                
                HStack {
                    Spacer()
                    Button(action: {
                        withAnimation {
                            showPopup.toggle()
                        }
                    }) {
                        Image(systemName: "info.circle")
                            .font(.largeTitle)
                            .padding()
                            .foregroundColor(.black)
                            .clipShape(Circle())
                    }
                    .padding(.trailing, 20)
                    .padding(.bottom, 20)
                }
            }
            
            if showPopup {
                PopupView3(showPopup: $showPopup, images: images, imageTexts: $imageTexts, fullscreenImageIndex: $fullscreenImageIndex)
                    .transition(.scale)
                    .zIndex(1)
            }
            
            if let index = fullscreenImageIndex {
                FullscreenImageView2(images: images, descriptions: imageTexts, currentIndex: index, fullscreenImageIndex: $fullscreenImageIndex)
                    .zIndex(2)
            }
        }
    }
    
    @ViewBuilder
    private func contentBox(title: String, description: String, linkURL: String, actionURL: String? = nil) -> some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
                .lineLimit(2)
                .minimumScaleFactor(0.5)
                .foregroundColor(.black)
            
            Divider()
            
            Text(description)
                .font(.subheadline)
                .foregroundColor(.black)
            
            Text("Link")
                .font(.subheadline)
                .foregroundColor(.blue)
                .underline()
                .onTapGesture {
                    if let url = URL(string: linkURL) {
                        UIApplication.shared.open(url)
                    }
                }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(radius: 5)
        .frame(height: 200)
        .padding(.horizontal)
        .onTapGesture {
            if let urlString = actionURL, let url = URL(string: urlString) {
                UIApplication.shared.open(url)
            }
        }
    }


struct ViewCDrawingLine {
    var points: [CGPoint]
    var color: Color
}

struct FullscreenImageView2: View {
    let images: [String]
    let descriptions: [String]
    @State var currentIndex: Int
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack {
                TabView(selection: $currentIndex) {
                    ForEach(0..<images.count, id: \.self) { index in
                        VStack {
                            Image(images[index])
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                                .onTapGesture {
                                    withAnimation {
                                        fullscreenImageIndex = nil
                                    }
                                }
                                .padding()
                            
                            ScrollView {
                                Text(descriptions[index])
                                    .padding()
                                    .background(
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(Color.white)
                                            .overlay(
                                                RoundedRectangle(cornerRadius: 10)
                                                    .stroke(Color.black, lineWidth: 1)
                                            )
                                    )
                                    .padding()
                                    .foregroundColor(.black)
                                    .multilineTextAlignment(.center)
                            }
                            .frame(maxHeight: 150)
                        }
                        .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle())
                .indexViewStyle(PageIndexViewStyle())
                Spacer()
            }
        }
    }
}
struct PopupView3: View {
    @Binding var showPopup: Bool
    let images: [String]
    @Binding var imageTexts: [String]
    @State private var currentPage: Int = 0
    @State private var isFullScreen: Bool = false
    @Binding var fullscreenImageIndex: Int?
    var body: some View {
        VStack(spacing: 20) {
           Text("Che cos'è un'App sulle App?")
                .font(.headline)
                .padding()
            
            TabView(selection: $currentPage) {
                ForEach(0..<images.count, id: \.self) { index in
                    VStack {
                        ZStack {
                            Image(images[index])
                                .resizable()
                                .aspectRatio(contentMode: isFullScreen ? .fit : .fill)
                                .frame(width: isFullScreen ? UIScreen.main.bounds.width : 400, height: isFullScreen ? UIScreen.main.bounds.height : 300)
                                .onTapGesture {
                                    withAnimation {
                                        fullscreenImageIndex = index
                                    }
                                }
                            
                            if isFullScreen {
                                VStack {
                                    Spacer()
                                    Text(imageTexts[index])
                                        .font(.body)
                                        .multilineTextAlignment(.center)
                                        .padding()
                                        .background(RoundedRectangle(cornerRadius: 10).fill(Color.white).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.black, lineWidth: 1)))
                                        .padding()
                                        .foregroundColor(.black)
                                }
                                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                                .transition(.opacity)
                            }
                        }
                        
                        if !isFullScreen {
                            ScrollView {
                                Text(imageTexts[index])
                                    .font(.body)
                                    .multilineTextAlignment(.center)
                                    .padding()
                                    .background(Color.white)
                                    .cornerRadius(10)
                                    .frame(maxWidth: .infinity, alignment: .center)
                                    .foregroundColor(.black)
                            }
                            .frame(height: 100)
                        }
                    }
                    .tag(index)
                }
            }
            .tabViewStyle(PageTabViewStyle())
            .frame(width: isFullScreen ? UIScreen.main.bounds.width : 600, height: isFullScreen ? UIScreen.main.bounds.height : 400)
            
            Text("\(currentPage + 1) of \(images.count)")
                .font(.footnote)
                .padding(-10)
            
            Button(action: {
                withAnimation {
                    showPopup = false
                }
            }) {
                Image(systemName: "xmark.circle")
                    .font(.title2)
                    .padding()
                    .foregroundColor(.black)
                    .cornerRadius(10)
            }
        }
        .frame(width: isFullScreen ? UIScreen.main.bounds.width : 600, height: isFullScreen ? UIScreen.main.bounds.height : 600)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(radius: 20)
        .padding()
    }
} 
    struct ViewC_Previews: PreviewProvider {
        static var previews: some View {
            ViewC()
        }
    }
