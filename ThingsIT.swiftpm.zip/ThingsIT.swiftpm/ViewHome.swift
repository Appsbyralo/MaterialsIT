import SwiftUI

struct ViewHome: View {
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            GeometryReader { geometry in
                VStack(alignment: .center, spacing: 30) {
                    Text("Cose per iniziare")
                        .font(.system(size: 50, weight: .bold))
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0))
                        .padding(.top, 60)
                        .frame(maxWidth: .infinity) 
                        .lineLimit(1) 
                        .minimumScaleFactor(0.5) 
                    
                    Text("L'idea dietro le schede in questa app è di darti alcune idee per iniziare con la tua app. Sentiti libero di copiare questo codice nella tua app, modificarlo e svilupparlo.")
                        .font(.system(size: 20, weight: .regular))
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0))
                        .frame(maxWidth: 600)
                        .multilineTextAlignment(.center)
                        .padding(.top, 20) 
                }
                .frame(width: geometry.size.width, height: geometry.size.height, alignment: .center)
                .padding(.bottom, 100)
            }
        }
    }
}

struct ViewHome_Previews: PreviewProvider {
    static var previews: some View {
        ViewHome()
    }
}
